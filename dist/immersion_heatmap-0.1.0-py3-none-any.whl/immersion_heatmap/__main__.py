import immersion_heatmap.heatmap as heatmap

if __name__ == "__main__":
    heatmap.run()